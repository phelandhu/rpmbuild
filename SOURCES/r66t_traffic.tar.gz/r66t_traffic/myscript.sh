#!/bin/bash
echo "Hello World" >> /tmp/test.txt
